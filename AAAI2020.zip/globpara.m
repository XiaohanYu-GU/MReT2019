function  gl=glob(v)
s2=regionprops(v, 'Area');
s = cat(1, s2.Area);

%%%%%%% Eccentricity

s2=regionprops(v, 'Eccentricity');
hs = cat(1, s2.Eccentricity);
gl(1)=hs;

%%%%%%% rectangularity
s2=regionprops(v, 'BoundingBox');
s3 = cat(1, s2.BoundingBox);
lx=s3(3);
ly=s3(4);

gl(2)=s/(lx*ly);

s4 = regionprops(v,'Perimeter');
s5 = cat(1, s4.Perimeter);
gl(3) = s/s5;

















