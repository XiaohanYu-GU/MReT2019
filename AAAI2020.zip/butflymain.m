clear;

sData		='./data/';

database = 4; %% 

if database == 4

%  sImage_in = 'C:\Users\s5058775\Desktop\code\AAAI2020\Leeds_btf_patchy_dataset\interior patches\';
%     sImage_ex = 'C:\Users\s5058775\Desktop\code\AAAI2020\Leeds_btf_patchy_dataset\complementary patches\';
%   sImage_all = 'C:\Users\s5058775\Desktop\code\AAAI2020\Leeds_btf_patchy_dataset\segmentations\';
%  
%   sImage_in = 'C:\Users\s5058775\Desktop\code\AAAI2020\IwPIS\interior patches\';
%   sImage_ex = 'C:\Users\s5058775\Desktop\code\AAAI2020\IwPIS\complementary patches\';
%   sImage_all = 'C:\Users\s5058775\Desktop\code\AAAI2020\IwPIS\segmentations\';
 
  sImage_in = 'C:\Users\s5058775\Desktop\code\AAAI2020\SoyCultivarVein\p2\interior patches\';
  sImage_ex = 'C:\Users\s5058775\Desktop\code\AAAI2020\SoyCultivarVein\p2\complementary patches\';
  sImage_all = 'C:\Users\s5058775\Desktop\code\AAAI2020\SoyCultivarVein\p2\segmentations\';
  
n_class = 100;
    n_obj = 2;
end


n_objall	= n_obj*n_class;
n_bull		= 2*n_obj;
labels		= ceil((1:n_objall)/n_obj);

n_contsamp	= 256;
sCont		= [sData 'cont_' i2s(n_contsamp) '.mat'];
sglob		= [sData 'globf_leafn'  '.mat'];

%-- Extract contours (save in cont_all)and caculate eccentricity and rectangularity  (save in globf)------
	if database == 4
[cont_all,poissonrs,imshape,imshape1,imshape2] = bflextract_contour(sImage_all,sImage_in,sImage_ex,n_class,n_obj,n_contsamp,database);    
% [cont_all,poissonrs,imshape,imshape1,imshape2] = btffeature_extraction_scale_invariant(sImage_all,sImage_in,sImage_ex,n_class,n_obj,n_contsamp,database);    

    else
        [cont_all,globf,poissonrs,imshape,imshape1,imshape2] = extract_contour_leaf(sImage,n_class,n_obj,n_contsamp,database);    

    end

%-- Extract features from contour-------------------------------------------------------------
wm=n_class; wn=n_obj;
t1=0; t2=0; t3=0; t4=0;
ls=2*wn;
km=7;
bb=256;
seg=7;

ny=km+1; nx=seg;
u=sqrt(-1);

for i=1:seg
 ea(i)=floor(bb/2^i);    
end;

kea=seg;
nn=n_objall;
prstmp1 = [];
prstmp2 = [];
for ik=1:nn
    prstmp1(ik) = poissonrs{ik}(1,1);
    prstmp2(ik) = poissonrs{ik}(1,2);
end
wh = prstmp1./(prstmp1+prstmp2);
wv = prstmp2./(prstmp1+prstmp2);
prstmp1=prstmp1/max(prstmp1);
prstmp2=prstmp2/max(prstmp2);
t0	= clock;
% prstmp=(prstmp-min(prstmp))/(max(prstmp)-min(prstmp));
for ik=1:nn
ik
  i=floor((ik-1)/wn)+1;
  j=ik-wn*(i-1);    
ims = imshape{ik};
ims1 = imshape1{ik};
ims2 = imshape2{ik};
dt=cont_all{ik};
% prs = poissonrs{ik};
prs1 = prstmp1(ik);

prs2 = prstmp2(ik);
for ki=1:3
 e1=ea(ki);    
[y3,y6]=btffeature_extraction(dt,bb,e1,km,u,ims,ims1,ims2);  
v1(ki,:)=y3(1,:);
v2(ki,:)=y3(2,:);
v3(ki,:)=y3(3,:);
v4(ki,:)=y3(4,:);
vv1(ki,:)=y6(1,:);
vv2(ki,:)=y6(2,:);
vv3(ki,:)=y6(3,:);
vv4(ki,:)=y6(4,:);
end; 

mn = bb*3;
fv2 = fft2(vv2)/mn;
absfv2 = abs(fv2(:,1:7));
fv3 = fft2(vv3)/mn;
absfv3 = abs(fv3(:,1:7));
absfv2(:,8)=0;
absfv3(:,8)=0;
 yyy2{i,j}=[v2(:,1:8);absfv2(:,1:8)];
 yyy3{i,j}=[v3(:,1:8);absfv3(:,1:8)];
 yyy1{i,j}=prs1;
 yyy4{i,j}=prs2;
end;  
disp( num2str(etime(clock,t0))); 
%%%%
result2=0;
gba = 0;
s = 0;
tmp_rs = {};
scale_num2=1;
starting = 1;

%%%%
%%%%%%%%%%%%caculate the dismilarity of any two shapes in the database 
result3=0;
t3 = 1;t2=1;t1=1;t4=1;t5=1;t6=1;
for ik=1:nn
    
    wi=floor((ik-1)/wn)+1;
    wj=ik-wn*(wi-1);
%     glm=globf{ik};
    fdm1=wh(ik)*yyy1{wi,wj};
    fdm2 =wv(ik)*yyy2{wi,wj};
        fdm3 =wh(ik)*yyy3{wi,wj};
        fdm4 =wv(ik)*yyy4{wi,wj};
    for jk=1:nn
        wi1=floor((jk-1)/wn)+1;
        wj1=jk-wn*(wi1-1);
%         gln=globf{jk};
        fdn1=wh(jk)*yyy1{wi1,wj1};
        fdn2 =wv(jk)*yyy2{wi1,wj1};
                fdn3 =wh(jk)*yyy3{wi1,wj1};
                 fdn4 =wv(jk)*yyy4{wi1,wj1};
        sfd(1:4)=0;

        sfd(1)=sfd(1)+sum(sum(abs(fdm1-fdn1)));
        sfd(2)=sfd(2)+sum(sum(abs(fdm2-fdn2)));
                sfd(3)=sfd(3)+sum(sum(abs(fdm3-fdn3)));
                sfd(4)=sfd(4)+sum(sum(abs(fdm4-fdn4)));

           s=0;
           s=t1*sfd(1)+t2*sfd(2)+t3*sfd(3)+t4*sfd(4);
        result3(wi,wj,wi1,wj1)=s;
        
    end;
    
end;

result = 1*result3;




    


