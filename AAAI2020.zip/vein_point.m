function [ veinpoint,vein ] = vein_point( filepath, veingrade, thinable)
%VEIN_POINT Summary of this function goes here
%   Detailed explanation goes here
    im = imread(filepath);
    imb = im(:,:,3);
    imr = im(:,:,1);
    img = im(:,:,2);
    mvein = im2bw(imr).*~im2bw(imb).*~im2bw(img);              %main vein
    svein = ~im2bw(imr).*im2bw(imb).*~im2bw(img);              %second vein
    tvein = im2bw(imr).*~im2bw(imb).*im2bw(img);               %third vein
    
    if(veingrade == 2)
        vein = mvein+svein;
    else
        vein = mvein+svein+tvein;
    end
    
    if(thinable == 1)
        vein = bwmorph(vein,'thin',Inf);
    end
    [mx,my] = find(vein == 1);
    veinpoint = [my,mx];
end

