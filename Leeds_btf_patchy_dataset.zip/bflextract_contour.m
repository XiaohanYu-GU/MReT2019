function [cont_all,poissonrs,imshape,imshape1,imshape2] = bflextract_contour(sImage_all,sdir,sdir_v,n_class,n_obj,n_contsamp,database)

%fprintf('Compute contours ......................... \n');
flag = 1;

cont_all		= cell(n_class*n_obj,1);
poissonrs = cell(n_class*n_obj,1);
imshape = cell(n_class*n_obj,1);
%% original contour
i_cur	= 1;
imbar = cell(n_class*n_obj,4);
for iC=1:n_class
    %figure(20); clf; hold on;
    if database ==1
        v1=['t' int2str(iC)];
    end
    %% swedish origin 2017/05/12
    if database == 2
        vswd = ['leaf' int2str(iC)];%%file folder name
    end
    if database == 3
        v1 = [int2str(iC)];
    end
    if database == 3
        list=dir(strcat(sdir,v1));   %list struct
        n=length(list);
        for i=1:n-2
            filename(i)={list(i+2).name};
        end
    end
    
    if database == 4
        v1 = [int2str(iC)];
        list=dir(strcat(sdir,v1));   %list struct
        n=length(list);
        for i=1:n-2
            filename(i)={list(i+2).name};
        end
        
        %                 v1 = [int2str(iC)];
        list2=dir(strcat(sdir_v,v1));   %list struct
        n2=length(list2);
        for i=1:n2-2
            filename2(i)={list2(i+2).name};
        end
        
                list3=dir(strcat(sImage_all,v1));   %list struct
        n2=length(list3);
        for i=1:n2-2
            filename3(i)={list3(i+2).name};
        end
    end
    if database == 5
        v1 = [int2str(iC)];
        if length(v1)==1
            v1 = strcat('00',v1);
        end
        if length(v1)==2
            v1 = strcat('0',v1);
        end
        list=dir(strcat(sdir,v1));   %list struct
        n=length(list);
        for i=1:n-2
            filename(i)={list(i+2).name};
        end
    end
    if database == 6
        v1 = [int2str(iC)];
        list=dir(strcat(sdir,v1));   %list struct
        n=length(list);
        for i=1:n-2
            filename(i)={list(i+2).name};
        end
    end
    
    for iO=1:n_obj
        %% swedish origin 2017/05/1
        if database == 3
            xx = strcat(sdir,v1,'/',char(filename(iO)));
            v = imread(xx);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end
        if database == 4
                      xx = strcat(sdir,v1,'/',char(filename(iO)));
            v = imread(xx);
            vrgb = v;
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;

            xx_all = strcat(sImage_all,v1,'/',char(filename3(iO)));
            v_v_all = imread(xx_all);
  
            xxv = strcat(sdir_v,v1,'/',char(filename2(iO)));
            v_v = imread(xxv);
  

            D1 = bwdist(~v,'euclidean');
            
            D11 = D1/max(max(D1));
            
            D2 = bwdist(~v_v,'euclidean');
            D22 = D2/max(max(D2));

        end
                if database == 5
            xx = strcat(sdir,v1,'/',char(filename(iO)));
            v = imread(xx);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end
        if database == 6
            xx = strcat(sdir,v1,'/',char(filename(iO)));
            v = imread(xx);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end
        
        if database == 2
            ch1 = ['l' int2str(iC) 'nr' i2s(iO,3)];
            s = strcat(sdir,vswd,'/',ch1,'.tif');
            v=imread(s);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end
        %      %%%%%%% leaf images of 100 species
        if database == 1
            ch1=['t' int2str(iO)];
            s=strcat(sdir,v1,'/',ch1,'.jpg');
            v=imread(s);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end

  F = D11+D22;
  sumf(1) = sum(sum(D22));%/sum(sum(F));%%%complementary part
  sumf(2) = sum(sum(D11));%/sum(sum(F));%%%vein part


        %- Extract contour, count only the longest contours
        [Cs]	= boundary_extract_binary(double(v_v_all));
        n_max	= 0;
        i_max	= 0;
        for ii=1:length(Cs)
            if size(Cs{ii},2)>n_max
                n_max = size(Cs{ii},2);
                i_max = ii;
            end
        end
        cont	= Cs{i_max}';
        
        %- Remove redundant point in contours
        cont		= [cont; cont(1,:)];
        dif_cont	= abs(diff(cont,1,1));
        id_gd		= find(sum(dif_cont,2)>0.001);
        cont		= cont(id_gd,:);
        
        %- Force the contour to be anti-clockwisecomputed above is at the different orientation
        bClock		= is_clockwise(cont);
        if bClock	cont	= flipud(cont);		end
        
        %- Start from bottom left
        [min_v,id]	= min(cont(:,2)+cont(:,1));
        cont		= circshift(cont,[length(cont)-id+1]);
        TTT = zeros(size(v_v));
        TTT(sub2ind(size(TTT),ceil(cont(:,2)),ceil(cont(:,1))))=1;
        %- Sampling if needed
        if exist('n_contsamp','var')
            [XIs,YIs]	= uniform_interp(cont(:,1),cont(:,2),n_contsamp-1);
            cont		= [cont(1,:); [XIs YIs]];
        end
        
        
        %- Save
        cont_all{i_cur}	= cont;
        poissonrs{i_cur} = sumf;
        if flag == 1;
             imshape{i_cur}=D22;%%complementary
             imshape1{i_cur}=D11;%%vein 
             imshape2{i_cur}=F;%%%whole
        else
             imshape{i_cur}= D11;
        end

        i_cur		= i_cur+1;
        

    end

end
