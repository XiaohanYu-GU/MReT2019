function [y5,y6]=feature_extraction(dt,bb,e,km,u,ims,ims1,ims2)
[mm,nn]=find(ims2>0);
testa = [mm,nn];
%  hold on;
%  scatter(nn,mm);
for j=1:bb
    k=j+e;
    if k>bb
        k=k-bb;
    end;
    is=(dt(k,1)-dt(j,1))+(dt(k,2)-dt(j,2))*u;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fh=0; nf=0; zh=0; nz=0; fh1=0;
    g=1+j;
    if g>bb
        g=g-bb;
    end;
    Local_Integral_EDT1=0;
    Local_Integral_EDT2=0;
    
    %%%%compute the area between two parallel boundary lines
    k_boundary = (dt(j,1)-dt(k,1))/(dt(k,2)-dt(j,2));
    
    if (k_boundary == Inf) || (k_boundary == -Inf)
        testxx = testa(:,2);
        if_inside = (dt(j,1)-testxx).*(dt(g,1)-testxx);
    else
        testxx = testa(:,2).*k_boundary;
        testyy = testa(:,1);
        if_online = testyy-testxx;
        line_j = if_online-(dt(j,2)-k_boundary*dt(j,1));
        line_k = if_online-(dt(k,2)-k_boundary*dt(k,1));
        if_inside = line_j.*line_k;
    end
    mma=find(if_inside<0);
    TTT = zeros(size(ims2));
    TTT(sub2ind(size(TTT),testa(mma,1),testa(mma,2)))=1;
    newTTT = TTT.*ims;%%%hybrid
    newTTT1 = TTT.*ims1;%%%vein
    Local_Integral_EDT1 =Local_Integral_EDT1+sum(sum(newTTT));%%%hybrid
    Local_Integral_EDT2 =Local_Integral_EDT2+sum(sum(newTTT1));%%%vein
    r2(j) = Local_Integral_EDT2;%%%vein
    r1(j)=0;
    r3(j)=Local_Integral_EDT1;
    r4(j)=0;
end;
%
s80=max(r2);
if s80>0
    r2 = r2/s80;
    
end;
s80=max(r3);
if s80>0
    r3 = r3/s80;
    
end;


y6=zeros(4,bb);


y6(1,:)=r1;
y6(2,:)=r2;
y6(3,:)=r3;
y6(4,:)=r4;


%%% orgin fft
z2=fft(r2);
z3=fft(r3);
z4=fft(r4);
z1=fft(r1);

y5=zeros(4,km);


y5(1,:)=abs(z1(1:km))/bb;
y5(2,:)=abs(z2(1:km))/bb;
y5(3,:)=abs(z3(1:km))/bb;
y5(4,:)=abs(z4(1:km))/bb;

y5(1,km+1)=std(r1);
y5(2,km+1)=std(r2);
y5(3,km+1)=std(r3);
y5(4,km+1)=std(r4);
%%% end



