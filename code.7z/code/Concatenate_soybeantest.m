clear
load ../FeatureMatrix/p1v3correct.mat;
yy1 = yyy1;
yy2 = yyy2;
yy3 = yyy3;
yy4 = yyy4;
load ../FeatureMatrix/p2v3correct.mat;
yy11 = yyy1;
yy22 = yyy2;
yy33 = yyy3;
yy44 = yyy4;
load ../FeatureMatrix/p3v3correct.mat;
yy111= yyy1;
yy222 = yyy2;
yy333 = yyy3;
yy444 = yyy4;
nnum = 7;
rowstartnum=1;
rowendnum = 6;
t1  =1;t2=4.5;t3 =t1;t4=t2;
% %%t2,t4:vein local
% %%t1,t3:complementary
tst = 0;
tinterval = 0.1;
tend = 8;
numm = 0;
weight = [];

n_class =100;
n_obj = 2;
wm=n_class; wn=n_obj;
nn=wm*wn;
result3 = 0;


wh(1:512)=1;
wv(1:512)=1;
for ik=1:nn
    wi=floor((ik-1)/wn)+1;
    wj=ik-wn*(wi-1);
    fdm1=wh(ik)*(yy1{wi,wj}+yy11{wi,wj}+1*yy111{wi,wj});
    fdm2=wv(ik)*(yy2{wi,wj}(rowstartnum:rowendnum,1:nnum)+yy22{wi,wj}(rowstartnum:rowendnum,1:nnum)+1*yy222{wi,wj}(rowstartnum:rowendnum,1:nnum));
    fdm3=wh(ik)*(yy3{wi,wj}(rowstartnum:rowendnum,1:nnum)+yy33{wi,wj}(rowstartnum:rowendnum,1:nnum)+1*yy333{wi,wj}(rowstartnum:rowendnum,1:nnum));
    fdm4=wv(ik)*(yy4{wi,wj}+yy44{wi,wj}+1*yy444{wi,wj});
    for jk=1:nn
        wi1=floor((jk-1)/wn)+1;
        wj1=jk-wn*(wi1-1);
        fdn1=wh(jk)*(yy1{wi1,wj1}+yy11{wi1,wj1}+1*yy111{wi1,wj1});
        fdn2=wv(jk)*(yy2{wi1,wj1}(rowstartnum:rowendnum,1:nnum)+yy22{wi1,wj1}(rowstartnum:rowendnum,1:nnum)+1*yy222{wi1,wj1}(rowstartnum:rowendnum,1:nnum));
        fdn3=wh(jk)*(yy3{wi1,wj1}(rowstartnum:rowendnum,1:nnum)+yy33{wi1,wj1}(rowstartnum:rowendnum,1:nnum)+1*yy333{wi1,wj1}(rowstartnum:rowendnum,1:nnum));
        fdn4=wv(jk)*(yy4{wi1,wj1}+yy44{wi1,wj1}+1*yy444{wi1,wj1});
        sfd(1:6)=0;
        sfd(1)=sfd(1)+sum(sum(abs(fdm1-fdn1)));
        sfd(2)=sfd(2)+sum(sum(abs(fdm2-fdn2)));
        sfd(3)=sfd(3)+sum(sum(abs(fdm3-fdn3)));
        sfd(4)=sfd(4)+sum(sum(abs(fdm4-fdn4)));
        s=0;
        s=t1*sfd(1)+t2*sfd(2)+t3*sfd(3)+t2*sfd(4);
        result3(wi,wj,wi1,wj1)=s;
    end;
end;
result = result3;

database = 4;

for i = 1:wm
    for j = 1:wn
        for i1 = 1:wm
            for j1 = 1:wn
                dismat(((i1-1)*wn+j1),((i-1)*wn+j)) = result(i1,j1,i,j);
            end
        end
    end
end

if database == 4
    
    n_class = wm;
    m=wm; n=2;
    mm=m*n;
    
    
    
    sss=0;
    
    for kk=1:1000
        
        
        for i=1:n_class
            k=1;
            z(1:2)=0;
            while k<=1
                
                t=floor(rand*2)+1;
                if z(t)==0
                    w(i,k)=t;
                    z(t)=1;
                    k=k+1;
                end;
            end;
            k=0;k1=0;
            for j=1:2
                
                if z(j)==0
                    k=k+1;
                    n(i,k)=j;
                end;
                
                if z(j)==1
                    k1=k1+1;
                    w(i,k1)=j;
                end;
                
            end;
            
            
        end;
        
        
        m=0;
        for i=1:n_class
            for j=1:1
                i1=1; j1=w(1,1);
                for t=1:n_class
                    for k=1:1
                        if result(i,n(i,j),t,w(t,k))<result(i,n(i,j),i1,j1)
                            i1=t; j1=w(t,k);
                        end;
                    end;
                end;
                
                if i1==i
                    m=m+1;
                end;
            end;
        end;
        
        
        s=m/(n_class*1);
        
        sss=sss+s;
        sssdev(kk)=s;
        
    end;
    
    r=sss/1000;
    dev1000 = std(sssdev);
    fprintf('\nClassification rate = %.4f', r);
    
end


%%%%%%%%%%%%%%%% compute classification with 1_nearest_neighbor
sm=0;
wn1 = 1;
wn = 2;
for i = 1:wm
    for j = (wn1+1):wn
        k1 = 0;
        for i1 = 1:wm
            for j1 = 1:wn1
                k1 = k1 + 1;
                pk2(k1) = result(i,j,i1,j1);
            end
        end
        [W,QQ]=sort(pk2);
        pe=floor((QQ(1)-1)/wn1)+1;
        if pe == i
            sm = sm + 1;
        end
    end
end

rs = sm/((wn-wn1)*wm);
% disp( num2str(etime(clock,t0)));
disp(rs);
fprintf('\n 1NNresult = %.2f\n', 100*rs);
%fprintf(fid,'%.2f\t',100*rs);



vv=20;
xh(1:wm)=wn;
all=sum(xh);

[i,cn]=size(xh);
bz=xh;
bd(1)=bz(1);
for i=2:cn
    bd(i)=bd(i-1)+bz(i);
end;
pr(1:vv)=0;
pree=zeros(1,all);
kkk=1; qd=1;zd=bd(1); l=1;
for i=1:all
    
    if i>bd(kkk)
        kkk=kkk+1;
        qd=zd+1;
        zd=bd(kkk);
        l=l+1;
    end;
    
    
    pk=dismat(i,1:all);
    [W,Q]=sort(pk);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%compute MAP
    pre=0; t=1; k=1; js=0;ik=1;temp=[];
    
    while t
        if (Q(k)<=zd) & (Q(k)>=qd)
            js=js+1;
            pre=pre+(js/k);
            
            if js==bz(l);
                t=0;
            end;
        end;
        k=k+1;
    end;
    
    pree(i)=pre/bz(l);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for j=1:vv
        gs=round(bz(l))*j/vv;
        t=0;js=0;
        while js<gs
            t=t+1;
            if (Q(t)<=zd) & (Q(t)>=qd)
                js=js+1;
            end;
        end;
        pp(i,j)=js/t;
    end;
end;

pr(j)=pr(j)/all;
pr(1:vv)=0;
for i=1:vv
    for j=1:all
        pr(i)=pr(i)+pp(j,i);
    end;
end;
%pr=pr/all

MAP=sum(pree(1:all))/all



ls=2*wn;
sm=0;

for i=1:wm
    for j=1:wn
        
        k=0;
        for i1=1:wm
            for j1=1:wn
                k=k+1;
                pk1(k)=result(i,j,i1,j1);
            end;
            
        end;
        [W,QQ]=sort(pk1);
        m=0;
        for t=1:ls
            pe=floor((QQ(t)-1)/wn)+1;
            po=QQ(t)-wn*(pe-1);
            
            if pe==i
                sm=sm+1;
                
            end;
        end;
    end;
end;

s=sm/(wm*wn*wn);
%   disp( num2str(etime(clock,t0)));
disp(s);
fprintf('\nBullseye score = %.2f', 100*s);


