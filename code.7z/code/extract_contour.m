function [vh,cont_all,globf,poissonrs,imshape,imshape1,imshape2] = extract_contour(sdir,sdir_v,n_class,n_obj,n_contsamp,database)

flag = 1;
cont_all		= cell(n_class*n_obj,1);
poissonrs = cell(n_class*n_obj,1);
imshape = cell(n_class*n_obj,1);
%% original contour
i_cur	= 1;
imbar = cell(n_class*n_obj,4);
for iC=1:n_class
    %figure(20); clf; hold on;
    if database ==1
        v1=['t' int2str(iC)];
    end
    %% swedish origin 2017/05/12
    if database == 2
        vswd = ['leaf' int2str(iC)];%%file folder name
    end
    if database == 3
        v1 = [int2str(iC)];
    end
    if database == 3
        list=dir(strcat(sdir,v1));   %list struct
        n=length(list);
        for i=1:n-2
            filename(i)={list(i+2).name};
        end
    end
    
    if database == 4
        v1 = [int2str(iC)];
        list=dir(strcat(sdir,v1));   %list struct
        n=length(list);
        for i=1:n-2
            filename(i)={list(i+2).name};
        end
    end
    if database == 5
        v1 = [int2str(iC)];
        if length(v1)==1
            v1 = strcat('00',v1);
        end
        if length(v1)==2
            v1 = strcat('0',v1);
        end
        list=dir(strcat(sdir,v1));   %list struct
        n=length(list);
        for i=1:n-2
            filename(i)={list(i+2).name};
        end
    end
    if database == 6
        v1 = [int2str(iC)];
        list=dir(strcat(sdir,v1));   %list struct
        n=length(list);
        for i=1:n-2
            filename(i)={list(i+2).name};
        end
    end
    
    for iO=1:n_obj
        %% swedish origin 2017/05/1
        if database == 3
            xx = strcat(sdir,v1,'/',char(filename(iO)));
            v = imread(xx);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end
        if database == 4
            xx = strcat(sdir,v1,'/',char(filename(iO)));
            v = imread(xx);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
            
            %%%vein
            xxv = strcat(sdir_v,v1,'/',char(filename(iO)));
            v_v = imread(xxv);
            if ndims(v_v)>2
                v_v= rgb2gray(v_v);
                test_v_v = v_v;
            end;
            level_v = graythresh(v_v);
            v_v=im2bw(v_v,level_v);
            v_v=~v_v;
        end
        if database == 5
            xx = strcat(sdir,v1,'/',char(filename(iO)));
            v = imread(xx);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end
        if database == 6
            xx = strcat(sdir,v1,'/',char(filename(iO)));
            v = imread(xx);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end
        
        if database == 2
            ch1 = ['l' int2str(iC) 'nr' i2s(iO,3)];
            s = strcat(sdir,vswd,'/',ch1,'.tif');
            v=imread(s);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end
        %      %%%%%%% leaf images of 100 species
        if database == 1
            ch1=['t' int2str(iO)];
            s=strcat(sdir,v1,'/',ch1,'.jpg');
            v=imread(s);
            if ndims(v)>2
                v= rgb2gray(v);
                test_v = v;
            end;
            level = graythresh(v);
            v=im2bw(v,level);
            v=~v;
        end
        
        if exist(xxv)
            [vein_all{i_cur},vein] = vein_point(xxv, 3, 0);
            [vein_all2{i_cur},vein2] = vein_point(xxv, 2, 0);
        end
        % %
        v=double(v);
        gl=globpara(v);
        im= double(v);
        im	= double(im>.5);
        
        %%%%vein
        v_v = double(vein);
        im_v = double(v_v);
        im_v = double(im_v>.5);
        im_bw11_v = im2bw(im_v);
        im_bw1_v = imfill(im_bw11_v,'holes');
        %%%
        
        
        v_v2 = double(vein2);
        im_v2 = double(v_v2);
        im_v2 = double(im_v2>.5);
        im_bw11_v2 = im2bw(im_v2);
        im_bw1_v2 = imfill(im_bw11_v2,'holes');
        
        
        
        im_bw11 = ~im2bw(test_v);
        im_bw1= imfill(im_bw11,'holes');
        vh(i_cur) = sum(sum(im_bw1_v))/(sum(sum(im_bw1))-sum(sum(im_bw1_v)));
        
        if flag == 1%% seperate vein
            I2 = ~im_bw1_v;
            I3 = I2+im_bw11_v;
            I4 = ~I3;
            [row,col]=size(I4);
            TT = zeros(size(I4));
            T1 = TT;
            T2 = TT;%%v3 in h2;
            [B,L] = bwboundaries(I4,'noholes');
            
            sum22 = 0;
            para = 0;
            for k = 1:length(B)
                boundary = B{k};
                
                
                TT = zeros(size(I4));
                
                TT(sub2ind(size(TT),boundary(:,1),boundary(:,2)))=1;
                
                
                
                
                
                
                TTT = imfill(TT,'holes');
                
                D1 = bwdist(~TTT,'euclidean');
                D11 = D1/max(max(D1));
                
                T1 = T1+D11.*double(im_bw1_v2);
                T2 = T2+D11.*double(1-im_bw1_v2);
                %%%% scale-3 vein inside s2 vein
                sum22(k) = sum(sum(D11.*double(im_bw1_v2)));
                
                
            end
            
            xx
            sum2_v = sum(sum22);
            
            para = 0;
            
            newMat = im_bw1-im_bw1_v;
            
            E1 = bwdist(~newMat,'euclidean');
            E11 = E1/max(max(E1));
            
            T2= E11+T2;
            F = T2+T1;
            sumf(1) = sum(sum(T2));%%%complementary part
            sumf(2) = sum(sum(T1));%%%vein part
            
            imwrite(T1,['v' '_' v1 '_' int2str(iO), '.png'], 'png');
            imwrite(T2,['h' '_' v1 '_' int2str(iO), '.png'], 'png');
            
        end
        
        if flag == 0
            % %%% test for distance transform
            im1 = im_bw1;
            para = 0;
            D1 = bwdist(~im1,'euclidean');
            D11 = D1/max(max(D1));
            D11(D11<para)=0;
            sum2 = sum(sum(D11));
        end
        
        
        %- Extract contour, count only the longest contours
        [Cs]	= boundary_extract_binary(double(im_bw1));
        n_max	= 0;
        i_max	= 0;
        for ii=1:length(Cs)
            if size(Cs{ii},2)>n_max
                n_max = size(Cs{ii},2);
                i_max = ii;
            end
        end
        cont	= Cs{i_max}';
        
        %- Remove redundant point in contours
        cont		= [cont; cont(1,:)];
        dif_cont	= abs(diff(cont,1,1));
        id_gd		= find(sum(dif_cont,2)>0.001);
        cont		= cont(id_gd,:);
        
        %- Force the contour to be anti-clockwisecomputed above is at the different orientation
        bClock		= is_clockwise(cont);
        if bClock	cont	= flipud(cont);		end
        
        %- Start from bottom left
        [min_v,id]	= min(cont(:,2)+cont(:,1));
        cont		= circshift(cont,[length(cont)-id+1]);
        
        
        %- Sampling if needed
        if exist('n_contsamp','var')
            [XIs,YIs]	= uniform_interp(cont(:,1),cont(:,2),n_contsamp-1);
            cont		= [cont(1,:); [XIs YIs]];
        end
        
        
        %- Save
        cont_all{i_cur}	= cont;
        
        poissonrs{i_cur} = sumf;
        if flag == 1;
            imshape{i_cur}=T2;%%complementary
            imshape1{i_cur}=T1;%%vein
            imshape2{i_cur}=F;%%%whole
        else
            imshape{i_cur}= D11;
        end
        globf{i_cur}	= gl;
        i_cur		= i_cur+1;
        
    end
end
