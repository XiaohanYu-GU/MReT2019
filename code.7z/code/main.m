clear;

t0	= clock;
sData		='./data/';

database = 4; %% soybean part 1


%%%%% soybean leaf part 1, 100 cultivars, 100*2 samples
if database == 4
    sImage_c = './test/contour/';%%% replace the path with user's own path for contour
    sImage_v = './test/vein/';%%% replace the path with user's own path for vein
    n_class = 100;
    n_obj = 2;
end



n_objall	= n_obj*n_class;
n_bull		= 2*n_obj;
labels		= ceil((1:n_objall)/n_obj);

n_contsamp	= 256;
sCont		= [sData 'cont_' i2s(n_contsamp) '.mat'];
sglob		= [sData 'globf_leafn'  '.mat'];

%-- Extract contours (save in cont_all)and caculate eccentricity and rectangularity  (save in globf)------

[vh,cont_all,globf,poissonrs,imshape,imshape1,imshape2] = extract_contour(sImage_c,sImage_v,n_class,n_obj,n_contsamp,database);


%-- Extract features from contour-------------------------------------------------------------
wm=n_class; wn=n_obj;
t1=0; t2=0; t3=0; t4=0;
ls=2*wn;
km=7;
bb=256;
seg=7;

ny=km+1; nx=seg;
u=sqrt(-1);

for i=1:seg
    ea(i)=floor(bb/2^i);
end;

kea=seg;
nn=n_objall;
prstmp1 = [];
prstmp2 = [];
for ik=1:nn
    prstmp1(ik) = poissonrs{ik}(1,1);
    prstmp2(ik) = poissonrs{ik}(1,2);
end
wh = prstmp1./(prstmp1+prstmp2);
wv = prstmp2./(prstmp1+prstmp2);
prstmp1=prstmp1/max(prstmp1);
prstmp2=prstmp2/max(prstmp2);

for ik=1:nn
    ik
    i=floor((ik-1)/wn)+1;
    j=ik-wn*(i-1);
    ims = imshape{ik};
    ims1 = imshape1{ik};
    ims2 = imshape2{ik};
    dt=cont_all{ik};
    
    prs1 = prstmp1(ik);
    
    prs2 = prstmp2(ik);
    for ki=1:3
        e1=ea(ki);
        [y3,y6]=feature_extraction(dt,bb,e1,km,u,ims,ims1,ims2);
        v1(ki,:)=y3(1,:);
        v2(ki,:)=y3(2,:);
        v3(ki,:)=y3(3,:);
        v4(ki,:)=y3(4,:);
        vv1(ki,:)=y6(1,:);
        vv2(ki,:)=y6(2,:);
        vv3(ki,:)=y6(3,:);
        vv4(ki,:)=y6(4,:);
    end;
    
    %%2D fft concatenation
    mn = bb*3;
    fv2 = fft2(vv2)/mn;
    absfv2 = abs(fv2(:,1:7));
    fv3 = fft2(vv3)/mn;
    absfv3 = abs(fv3(:,1:7));
    absfv2(:,8)=0;
    absfv3(:,8)=0;
    yyy2{i,j}=[v2(:,1:8);absfv2(:,1:8)];
    yyy3{i,j}=[v3(:,1:8);absfv3(:,1:8)];
    yyy1{i,j}=prs1;
    yyy4{i,j}=prs2;%%vein
end;

%%%%
result2=0;
gba = 0;
s = 0;
tmp_rs = {};
scale_num2=1;
starting = 1;

%%%%
%%%%%%%%%%%%caculate the dismilarity of any two shapes in the database
result3=0;
t3 = 1;t2=1;t1=1;t4=1;t5=1;t6=1;
for ik=1:nn
    
    wi=floor((ik-1)/wn)+1;
    wj=ik-wn*(wi-1);
    glm=globf{ik};
    fdm1=wh(ik)*yyy1{wi,wj};
    fdm2 =wv(ik)*yyy2{wi,wj};
    fdm3 =wh(ik)*yyy3{wi,wj};
    fdm4 =wv(ik)*yyy4{wi,wj};
    for jk=1:nn
        wi1=floor((jk-1)/wn)+1;
        wj1=jk-wn*(wi1-1);
        gln=globf{jk};
        fdn1=wh(jk)*yyy1{wi1,wj1};
        fdn2 =wv(jk)*yyy2{wi1,wj1};
        fdn3 =wh(jk)*yyy3{wi1,wj1};
        fdn4 =wv(jk)*yyy4{wi1,wj1};
        sfd(1:4)=0;
        sfd(1)=sfd(1)+sum(sum(abs(fdm1-fdn1)));
        sfd(2)=sfd(2)+sum(sum(abs(fdm2-fdn2)));
        sfd(3)=sfd(3)+sum(sum(abs(fdm3-fdn3)));
        sfd(4)=sfd(4)+sum(sum(abs(fdm4-fdn4)));
        s=0;
        s=t1*sfd(1)+t2*sfd(2)+t3*sfd(3)+t4*sfd(4);
        result3(wi,wj,wi1,wj1)=s;
        
    end;
    
end;

disp( num2str(etime(clock,t0)));

result = 1*result3;

%%%%%%%%%%%%%%% compute retrieval accuracy "Bullseye score"

if database == 1
    sm=0;
    
    for i=1:wm
        for j=1:wn
            
            k=0;
            for i1=1:wm
                for j1=1:wn
                    k=k+1;
                    pk1(k)=result(i,j,i1,j1);
                end;
                
            end;
            [W,QQ]=sort(pk1);
            m=0;
            for t=1:ls
                pe=floor((QQ(t)-1)/wn)+1;
                po=QQ(t)-wn*(pe-1);
                
                if pe==i
                    sm=sm+1;
                    
                end;
            end;
        end;
    end;
    
    s=sm/(wm*wn*wn);
    %   disp( num2str(etime(clock,t0)));
    disp(s);
    fprintf('\nBullseye score = %.2f', 100*s);
end



if database == 2
    
    m=15; n=75;
    mm=m*n;
    
    
    
    sss=0;
    
    for kk=1:1000
        
        
        for i=1:15
            k=1;
            z(1:75)=0;
            while k<=25
                
                t=floor(rand*75)+1;
                if z(t)==0
                    w(i,k)=t;
                    z(t)=1;
                    k=k+1;
                end;
            end;
            k=0;k1=0;
            for j=1:75
                
                if z(j)==0
                    k=k+1;
                    n(i,k)=j;
                end;
                
                if z(j)==1
                    k1=k1+1;
                    w(i,k1)=j;
                end;
                
            end;
            
            
        end;
        
        
        m=0;
        for i=1:15
            for j=1:50
                i1=1; j1=w(1,1);
                for t=1:15
                    for k=1:25
                        if result(i,n(i,j),t,w(t,k))<result(i,n(i,j),i1,j1)
                            i1=t; j1=w(t,k);
                        end;
                    end;
                end;
                
                if i1==i
                    m=m+1;
                end;
            end;
        end;
        
        
        s=m/(15*50);
        
        sss=sss+s;
        
        
    end;
    
    r=sss/1000;
    
    fprintf('\nClassification rate = %.4f', r);
    
    
end


if database == 3||4
    sm=0;
    
    for i=1:wm
        for j=1:wn
            
            k=0;
            for i1=1:wm
                for j1=1:wn
                    k=k+1;
                    pk1(k)=result(i,j,i1,j1);
                end;
                
            end;
            [W,QQ]=sort(pk1);
            m=0;
            for t=1:ls
                pe=floor((QQ(t)-1)/wn)+1;
                po=QQ(t)-wn*(pe-1);
                
                if pe==i
                    sm=sm+1;
                    
                end;
            end;
        end;
    end;
    
    s=sm/(wm*wn*wn);
    %   disp( num2str(etime(clock,t0)));
    disp(s);
    fprintf('\nBullseye score = %.2f', 100*s);
end


if database == 4
    
    
    m=n_class; n=n_obj;
    mm=m*n;
    
    
    
    sss=0;
    
    for kk=1:1000
        
        
        for i=1:n_class
            k=1;
            z(1:n_obj)=0;
            while k<=1
                
                t=floor(rand*n_obj)+1;
                if z(t)==0
                    w(i,k)=t;
                    z(t)=1;
                    k=k+1;
                end;
            end;
            k=0;k1=0;
            for j=1:n_obj
                
                if z(j)==0
                    k=k+1;
                    n(i,k)=j;
                end;
                
                if z(j)==1
                    k1=k1+1;
                    w(i,k1)=j;
                end;
                
            end;
            
            
        end;
        
        
        m=0;
        for i=1:n_class
            for j=1:n_obj-1
                i1=1; j1=w(1,1);
                for t=1:n_class
                    for k=1:1
                        if result(i,n(i,j),t,w(t,k))<result(i,n(i,j),i1,j1)
                            i1=t; j1=w(t,k);
                        end;
                    end;
                end;
                
                if i1==i
                    m=m+1;
                end;
            end;
        end;
        
        
        s=m/(n_class*(n_obj-1));
        
        sss=sss+s;
        
        
    end;
    
    r=sss/1000;
    
    fprintf('\nClassification rate = %.4f', r);
    
    
end

